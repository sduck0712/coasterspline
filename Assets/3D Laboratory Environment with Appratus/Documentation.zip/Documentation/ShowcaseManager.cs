using UnityEngine;
using System.Collections.Generic;

public class ShowcaseManager : MonoBehaviour
{
    [Header("플레이트 프리팹")]
    public GameObject platePrefab;
    [Header("플레이트 생성 위치")]
    public Transform plateSpawnPoint;

    [Header("메인테이블 Anchor")]
    public Transform leftAnchor;
    public Transform rightAnchor;

    [Header("쇼케이스 내 원본 오브젝트")]
    public List<GameObject> showcaseObjects = new List<GameObject>();
    private List<Vector3> originalPositions = new List<Vector3>();
    private List<Quaternion> originalRotations = new List<Quaternion>();

    private GameObject currentPlate;
    private PlateDetector currentDetector;

    private void Awake()
    {
        // 쇼케이스 오브젝트 원위치 저장
        foreach (var obj in showcaseObjects)
        {
            if (obj != null)
            {
                originalPositions.Add(obj.transform.position);
                originalRotations.Add(obj.transform.rotation);
            }
        }
    }

    // 문 열 때 (플레이트 생성)
    public void OpenShowcase()
    {
        Debug.Log("[ShowcaseManager] OpenShowcase() 호출");

        if (currentPlate == null)
        {
            currentPlate = Instantiate(platePrefab, plateSpawnPoint.position, plateSpawnPoint.rotation);
            currentDetector = currentPlate.GetComponent<PlateDetector>();

            // 인스펙터에서 연결된 Left/RightAnchor, maxPerRow 등 전달
            if (currentDetector != null)
            {
                currentDetector.leftAnchor = leftAnchor;
                currentDetector.rightAnchor = rightAnchor;
                currentDetector.maxPerRow = showcaseObjects.Count;

                // 플레이트에 놓인 원본 오브젝트 리스트 전달
                currentDetector.plateOriginals = showcaseObjects;
            }
        }
    }

    // 문 닫기 & 리셋
    public void CloseShowcase()
    {
        Debug.Log("[ShowcaseManager] CloseShowcase() 호출");

        // 1. 플레이트 위에 있던 오브젝트 원위치로 복귀
        for (int i = 0; i < showcaseObjects.Count; i++)
        {
            if (showcaseObjects[i] != null)
            {
                showcaseObjects[i].transform.position = originalPositions[i];
                showcaseObjects[i].transform.rotation = originalRotations[i];
            }
        }

        // 2. 메인테이블 위 클론 모두 삭제
        if (currentDetector != null)
        {
            currentDetector.ClearClones();
        }

        // 3. 플레이트 제거
        if (currentPlate != null)
        {
            Destroy(currentPlate);
            currentPlate = null;
        }
        currentDetector = null;
    }

    // 플레이트 위의 원본 오브젝트를 수동으로 메인테이블로 복제하고 싶을 때(예시)
    public void MovePlateObjectsToMainTable()
    {
        if (currentDetector != null)
            currentDetector.SpawnClones();
    }
}
