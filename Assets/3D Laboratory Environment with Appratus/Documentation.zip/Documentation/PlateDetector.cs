using UnityEngine;
using System.Collections.Generic;

public class PlateDetector : MonoBehaviour
{
    [Header("클론이 복제될 메인테이블 Anchor")]
    public Transform leftAnchor;
    public Transform rightAnchor;
    public int maxPerRow = 6;

    [Header("플레이트 위에 놓을 수 있는 쇼케이스 오브젝트")]
    public List<GameObject> plateOriginals = new List<GameObject>();

    // 복제본 관리
    private List<GameObject> clones = new List<GameObject>();
    private int cloneCount = 0;

    // **복제본 생성 트리거 (예시: OnTriggerEnter/콜라이더 충돌 대신 함수로 수동 처리)**
    public void SpawnClones()
    {
        // plateOriginals 리스트에 있는 각 원본 오브젝트를 복제해서 메인테이블로
        ClearClones(); // 기존 클론 삭제 (중복 방지)
        cloneCount = 0;

        for (int i = 0; i < plateOriginals.Count && cloneCount < maxPerRow; i++)
        {
            GameObject original = plateOriginals[i];
            if (original == null) continue;

            float t = (float)cloneCount / Mathf.Max(1, maxPerRow - 1);
            Vector3 spawnPos = Vector3.Lerp(leftAnchor.position, rightAnchor.position, t);
            Quaternion spawnRot = Quaternion.Lerp(leftAnchor.rotation, rightAnchor.rotation, t);

            GameObject clone = Instantiate(original, spawnPos, spawnRot);
            clone.name = original.name + "_Clone";
            // 클론이 물리적으로 동작하려면 Rigidbody 등 세팅(필요시)
            Rigidbody rb = clone.GetComponent<Rigidbody>();
            if (rb != null)
            {
                rb.isKinematic = false;
                rb.useGravity = true;
            }
            clones.Add(clone);
            cloneCount++;
        }
        Debug.Log($"[PlateDetector] 메인테이블에 클론 {cloneCount}개 생성됨");
    }

    // 복제본 모두 삭제
    public void ClearClones()
    {
        foreach (var obj in clones)
        {
            if (obj != null)
                Destroy(obj);
        }
        clones.Clear();
        cloneCount = 0;
        Debug.Log("[PlateDetector] 메인테이블 클론 삭제 완료");
    }
}
