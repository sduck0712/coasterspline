using UnityEngine;

public class PlateFollowCamera : MonoBehaviour
{
    public Vector3 offsetFromCamera = new Vector3(0, -0.5f, 2f);  // 카메라 앞/아래로 위치

    void LateUpdate()
    {
        if (Camera.main != null)
        {
            // 카메라 기준 상대 위치로 Plate를 항상 이동
            transform.position = Camera.main.transform.position + Camera.main.transform.rotation * offsetFromCamera;
            transform.rotation = Camera.main.transform.rotation; // 필요시 Plate의 회전도 카메라에 맞추기
        }
    }
}
